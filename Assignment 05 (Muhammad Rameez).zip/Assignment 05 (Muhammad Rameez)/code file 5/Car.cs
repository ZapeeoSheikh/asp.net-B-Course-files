﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace code_file_05
{
    internal class Car
    {
        public string Name { get; set; }
        public int Model { get; set; }
        public string Company { get; set; }
        public double MaxSpeed { get; set; }
        public int EnginePower { get; set; }
        public string Color { get; set; }
        public bool IsFamilyCar { get; set; }
        public bool IsAuto { get; set; }
        public int Price { get; set; }



        /*1. Create a class of Name "Car"
          2. Add Properties
          Name
          Model
          Company
          MaxSpeed
          EnginePower
          Color
          IsFamilyCar
          IsAuto
          Price
          3. Make at least 3 objects with values
          4. Use foreach loop to print it*/
    }
}
