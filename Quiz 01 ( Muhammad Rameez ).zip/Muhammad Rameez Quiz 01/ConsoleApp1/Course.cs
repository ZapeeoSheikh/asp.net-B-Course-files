﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    public class Course
    {
        public string Title { get; set; }
        public double Duration { get; set; }
        public int Cost { get; set; }
        public string Description { get; set; }
    }
}
