﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    public class Calculator
    {
        public double Subtract(double first, double second)
        {
            double total = first - second;
            return total;
        }
    }
}
